package com.dongnao.battery.opt;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.BatteryManager;
import android.os.Build;
import android.os.PowerManager;
import android.provider.Settings;
import android.util.Log;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

/**
 * @author Lance
 * @date 2017/12/7
 */

public class Battery {


    private static final String TAG = "Battery";

    /**
     * 加入Doze白名单
     *
     * @param activity
     */
    public static void addDozeWhite(Activity activity) {
        PowerManager pm = (PowerManager) activity.getSystemService(Context.POWER_SERVICE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (!pm.isIgnoringBatteryOptimizations(activity.getPackageName())) {
                //弹出对话框
                Intent intent = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS);
                intent.setData(Uri.parse("package:" + activity.getPackageName()));

                //跳转白名单界面
//            Intent intent = new Intent( Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS);
//            startActivity(intent);
                activity.startActivity(intent);
            }
        }
    }

    /**
     * 是否插上插头(充电)
     *
     * @param context
     * @return
     */
    public static boolean isPlugged(Context context) {
        //BatteryManager会发送一个包含充电状态的持续广播, 我们可以通过此广播获取充电状态和电量详情
        IntentFilter filter = new IntentFilter(Intent.ACTION_BATTERY_CHANGED);
        //因为这是一个持续广播, 我们无需写receiver
        Intent batteryStatus = context.registerReceiver(null, filter);
        int chargePlug = batteryStatus.getIntExtra(BatteryManager.EXTRA_PLUGGED, -1);
        //ac或usb充电
        boolean acCharge = (chargePlug == BatteryManager.BATTERY_PLUGGED_AC);
        boolean usbCharge = (chargePlug == BatteryManager.BATTERY_PLUGGED_USB);
        //wifi充电
        boolean wirelessCharge = false;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
            wirelessCharge = (chargePlug == BatteryManager.BATTERY_PLUGGED_WIRELESS);
        }

        //获得电池电量
        int level = batteryStatus.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
        int scale = batteryStatus.getIntExtra(BatteryManager.EXTRA_SCALE, -1);
        float batteryPct = level / (float) scale;
        Log.i(TAG, "当前电池电量:" + batteryPct);
        return (usbCharge || acCharge || wirelessCharge);
    }

    /**
     * 是否为wifi并且可用网络
     *
     * @param context
     * @return
     */
    public static boolean isWifi(Context context) {
        ConnectivityManager connectivityManager = (ConnectivityManager) context
                .getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetInfo = connectivityManager.getActiveNetworkInfo();
        if (activeNetInfo != null && activeNetInfo.isConnected()
                && activeNetInfo.getType() == ConnectivityManager.TYPE_WIFI) {
            return true;
        }
        return false;
    }

}
