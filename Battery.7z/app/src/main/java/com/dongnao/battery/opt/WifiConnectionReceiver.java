package com.dongnao.battery.opt;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.widget.Toast;

/**
 * @author Lance
 * @date 2017/12/7
 */

public class WifiConnectionReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        if (Battery.isWifi(context)) {
            Toast.makeText(context.getApplicationContext(), "当前s处于wifi状态", Toast
                    .LENGTH_SHORT).show();
        } else {
            Toast.makeText(context.getApplicationContext(), "当前未处于wifi状态", Toast
                    .LENGTH_SHORT).show();
        }
    }
}
