package com.dongnao.battery;

import android.Manifest;
import android.app.job.JobInfo;
import android.app.job.JobScheduler;
import android.content.ComponentName;
import android.content.Context;
import android.os.Bundle;
import android.os.RemoteException;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;

import com.dongnao.battery.location.LocationServiceConnection;
import com.dongnao.battery.opt.Battery;
import com.dongnao.battery.opt.MyJobService;

/**
 * @author xiang
 */
public class MainActivity extends AppCompatActivity {

    private JobScheduler jobScheduler;

    private LocationServiceConnection locationServiceConnection;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ActivityCompat.requestPermissions(this, new String[]{Manifest.permission_group.LOCATION,
                Manifest.permission_group.STORAGE}, 10);


        locationServiceConnection = new LocationServiceConnection(new ILocationListener.Stub() {

            @Override
            public void onLocationChanged(String location) throws RemoteException {
                Log.i("lance", "MainActivity 获得了位置信息:" + location);
            }
        });
        bindService(App.getApplicationt().getLocation(), locationServiceConnection,
                BIND_AUTO_CREATE);

//        opt();
    }


    public void opt() {
        //加入doze白名单
        Battery.addDozeWhite(this);
        //获得是否在充电
        Battery.isPlugged(this);


        jobScheduler = (JobScheduler) getSystemService(Context.JOB_SCHEDULER_SERVICE);
//        for (int i = 0; i < 10; ++i) {
        JobInfo jobInfo = new JobInfo.Builder(0, new ComponentName(this, MyJobService
                .class))
                //延迟5s执行
                .setMinimumLatency(5_000)
                //充电
                .setRequiresCharging(true)
                //不是蜂窝网络时才执行
                //NETWORK_TYPE_NONE 无论有没有网络
                //NETWORK_TYPE_ANY 任意一种网络
                //NETWORK_TYPE_NOT_ROAMING 不漫游
                .setRequiredNetworkType(JobInfo.NETWORK_TYPE_UNMETERED).build();
        jobScheduler.schedule(jobInfo);
//        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
//        jobScheduler.cancelAll();
        unbindService(locationServiceConnection);
    }

}
