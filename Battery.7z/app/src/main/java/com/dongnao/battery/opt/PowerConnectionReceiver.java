package com.dongnao.battery.opt;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.text.TextUtils;
import android.widget.Toast;

/**
 * @author Lance
 * @date 2017/12/7
 */

public class PowerConnectionReceiver extends BroadcastReceiver {


    @Override
    public void onReceive(Context context, Intent intent) {
        //正在充电
        if (TextUtils.equals(intent.getAction(), Intent.ACTION_POWER_CONNECTED)) {
            Toast.makeText(context.getApplicationContext(), "当前处于充电状态", Toast
                    .LENGTH_SHORT).show();
        } else if (TextUtils.equals(intent.getAction(), Intent.ACTION_POWER_DISCONNECTED)) {
            Toast.makeText(context.getApplicationContext(), "当前未处于充电状态", Toast.LENGTH_SHORT)
                    .show();
        }
    }
}
