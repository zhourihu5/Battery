package com.dongnao.battery.location;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.IBinder;
import android.os.PowerManager;
import android.os.RemoteException;
import android.os.SystemClock;
import android.support.annotation.Nullable;

import com.dongnao.battery.ILocationInterface;
import com.dongnao.battery.ILocationListener;

/**
 * @author Lance
 * @date 2018/1/14
 */

public class LocationService extends Service {
    private Intent alarmIntent;
    private PendingIntent alarmPi;
    private AlarmManager alarm;
    private PowerManager.WakeLock locationLock;

    private ILocationInterface.Stub stub = new ILocationInterface.Stub() {


        @Override
        public void regiestLocationListener(ILocationListener listener) throws RemoteException {
            LocationManager.getInstance().addListener(listener);
        }

        @Override
        public void unRegiestLocationListener(ILocationListener listener) throws RemoteException {
            LocationManager.getInstance().removeListener(listener);
        }
    };

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return stub;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        LocationManager.getInstance().startLocation(this);
        PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
        //判断是否支持
//        pm.isWakeLockLevelSupported(PowerManager.PARTIAL_WAKE_LOCK)
        System.out.println("dongnao:" + pm.isWakeLockLevelSupported(PowerManager
                .PARTIAL_WAKE_LOCK));
        locationLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK,
                "location_lock");
        locationLock.acquire();
        //优化后
//        alarmKeep();
    }

    private void alarmKeep() {
        // 创建Intent对象，action为LOCATION
        alarmIntent = new Intent();
        alarmIntent.setAction("LOCATION");
        // 定义一个PendingIntent对象，PendingIntent.getBroadcast包含了sendBroadcast的动作。
        // 也就是发送了action 为"LOCATION"的intent
        alarmPi = PendingIntent.getBroadcast(this, 0, alarmIntent, 0);
        // AlarmManager对象,注意这里并不是new一个对象，Alarmmanager为系统级服务
        alarm = (AlarmManager) getSystemService(ALARM_SERVICE);
        //动态注册一个广播
        IntentFilter filter = new IntentFilter();
        filter.addAction("LOCATION");
        registerReceiver(alarmReceiver, filter);

        //设置一个闹钟，2秒之后每隔5秒执行启动一次定位程序
        alarm.setRepeating(AlarmManager.ELAPSED_REALTIME_WAKEUP, SystemClock.elapsedRealtime() +
                        2 * 1000,
                5 * 1000, alarmPi);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        LocationManager.getInstance().destoryLocation();
        if (null != locationLock) {
            locationLock.release();
        }
//        unregisterReceiver(alarmReceiver);
    }

    private BroadcastReceiver alarmReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (intent.getAction().equals("LOCATION")) {
                LocationManager.getInstance().startLocation(LocationService.this);
            }
        }
    };
}
