package com.dongnao.battery.location;

import android.content.Context;
import android.os.RemoteException;
import android.util.Log;
import android.util.SparseArray;

import com.amap.api.location.AMapLocation;
import com.amap.api.location.AMapLocationClient;
import com.amap.api.location.AMapLocationClientOption;
import com.amap.api.location.AMapLocationListener;
import com.dongnao.battery.ILocationListener;

/**
 * @author Lance
 * @date 2018/1/14
 */

public class LocationManager {
    //声明AMapLocationClient类对象
    private AMapLocationClient mLocationClient;

    private static LocationManager instance;

    private SparseArray<ILocationListener> listeners;
    private Context applicationContext;

    public LocationManager() {
        listeners = new SparseArray<>();
    }

    public static LocationManager getInstance() {
        if (null == instance) {
            instance = new LocationManager();
        }
        return instance;
    }

    //声明定位回调监听器
    public AMapLocationListener mLocationListener = new AMapLocationListener() {
        @Override
        public void onLocationChanged(AMapLocation aMapLocation) {
            if (aMapLocation != null) {
                if (aMapLocation.getErrorCode() == 0) {
                    //获得json
                    String location = aMapLocation.toStr();
                    //上传
                    UploadService.UploadLocation(applicationContext, location);
                    int size = listeners.size();
                    for (int i = 0; i < size; ++i) {
                        ILocationListener iLocationListener = listeners.valueAt(i);
                        try {
                            iLocationListener.onLocationChanged(location);
                        } catch (RemoteException e) {
                            e.printStackTrace();
                        }
                    }
                } else {
                    //定位失败时，可通过ErrCode（错误码）信息来确定失败的原因，errInfo是错误信息，详见错误码表。
                    Log.e("AmapError", "location Error, ErrCode:"
                            + aMapLocation.getErrorCode() + ", errInfo:"
                            + aMapLocation.getErrorInfo());
                }
            }
        }
    };

    public void startLocation(Context context) {
        if (null != mLocationClient) {
            mLocationClient.startLocation();
            return;
        }
        applicationContext = context.getApplicationContext();
        //初始化定位
        mLocationClient = new AMapLocationClient(applicationContext);
        //设置定位回调监听
        mLocationClient.setLocationListener(mLocationListener);
        //声明AMapLocationClientOption对象
        AMapLocationClientOption mLocationOption = null;
        //初始化AMapLocationClientOption对象
        mLocationOption = new AMapLocationClientOption();
        mLocationOption.setLocationMode(AMapLocationClientOption.AMapLocationMode.Hight_Accuracy);
        //设置定位间隔,单位毫秒,默认为2000ms，最低1000ms。
        mLocationOption.setInterval(1000);
        //设置是否返回地址信息（默认返回地址信息）
        mLocationOption.setNeedAddress(true);
        //设置是否允许模拟位置,默认为true，允许模拟位置
        mLocationOption.setMockEnable(true);
        //单位是毫秒，默认30000毫秒，建议超时时间不要低于8000毫秒。
        mLocationOption.setHttpTimeOut(20000);
        //关闭缓存机制
        mLocationOption.setLocationCacheEnable(false);
        //给定位客户端对象设置定位参数
        mLocationClient.setLocationOption(mLocationOption);
        //启动定位
        mLocationClient.startLocation();
    }

    public void stopLocation() {
        if (null != mLocationClient) {
            mLocationClient.stopLocation();//停止定位后，本地定位服务并不会被销毁
        }
    }

    public void destoryLocation() {
        listeners.clear();
        if (null != mLocationClient) {
            mLocationClient.unRegisterLocationListener(mLocationListener);
            mLocationClient.onDestroy();//销毁定位客户端，同时销毁本地定位服务。
            mLocationClient = null;
        }
    }

    public void addListener(ILocationListener listener) {
        listeners.put(listener.hashCode(), listener);
    }

    public void removeListener(ILocationListener listener) {
        listeners.remove(listener.hashCode());
    }
}
