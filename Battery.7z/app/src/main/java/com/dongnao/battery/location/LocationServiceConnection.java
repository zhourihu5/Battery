package com.dongnao.battery.location;

import android.content.ComponentName;
import android.content.ServiceConnection;
import android.os.IBinder;
import android.os.RemoteException;

import com.dongnao.battery.ILocationInterface;
import com.dongnao.battery.ILocationListener;

import java.lang.ref.WeakReference;

/**
 * @author Lance
 * @date 2018/1/14
 */

public class LocationServiceConnection implements ServiceConnection {
    WeakReference<ILocationListener> weakListener;
    ILocationInterface iLocationInterface;

    public LocationServiceConnection(ILocationListener listener) {
        weakListener = new WeakReference<>(listener);
    }

    @Override
    public void onServiceConnected(ComponentName name, IBinder service) {
        ILocationListener iLocationListener = weakListener.get();
        if (null != iLocationListener) {
            iLocationInterface = ILocationInterface.Stub.asInterface
                    (service);
            try {
                iLocationInterface.regiestLocationListener(iLocationListener);
            } catch (RemoteException e) {
                e.printStackTrace();
            }
        }
    }

    @Override
    public void onServiceDisconnected(ComponentName name) {
        ILocationListener iLocationListener = weakListener.get();
        if (null != iLocationInterface && null != iLocationListener) {
            try {
                iLocationInterface.unRegiestLocationListener(iLocationListener);
            } catch (RemoteException e) {
                e.printStackTrace();
            }
        }
        iLocationInterface = null;
    }
}