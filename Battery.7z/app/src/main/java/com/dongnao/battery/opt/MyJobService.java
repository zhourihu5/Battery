package com.dongnao.battery.opt;

import android.app.job.JobParameters;
import android.app.job.JobService;
import android.content.Intent;
import android.os.AsyncTask;
import android.util.Log;

import java.io.IOException;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;


/**
 * @author Lance
 * @date 2017/12/7
 */

public class MyJobService extends JobService {
    public static final String TAG = "JobService";

    @Override
    public void onCreate() {
        super.onCreate();
        Log.i(TAG, "JobService created");
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Log.i(TAG, "JobService destory");
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Log.i(TAG, "JobService destory");
        return super.onStartCommand(intent, flags, startId);
    }

    //当任务开始时执行
    @Override
    public boolean onStartJob(JobParameters params) {
        //如果返回值是false,这个方法返回时任务已经执行完毕。
        //如果返回值是true,那么这个任务正要被执行，我们就需要开始执行任务。
        //当任务执行完毕时你需要调用jobFinished(JobParameters params, boolean needsRescheduled)来通知系统
        if (Battery.isWifi(this)) {
            //因为不是蜂窝就执行，所以我们自己再判断是否wifi。
            new MyAsyncTask().execute(params);
            return true;
        }
        return false;
    }

    //当系统接收到一个取消请求时
    //如果onStartJob返回false,那么onStopJob不会被调用
    @Override
    public boolean onStopJob(JobParameters params) {
        return false;
    }

    class MyAsyncTask extends AsyncTask<JobParameters, Void, Void> {
        JobParameters jobParameters;

        @Override
        protected Void doInBackground(JobParameters[] objects) {
            jobParameters = objects[0];
            Log.i(TAG, jobParameters.getJobId() + " 任务开始执行......");
            HttpURLConnection conn = null;
            OutputStream os = null;
            try {
                conn = (HttpURLConnection) new URL("http://192.168.50.126")
                        .openConnection();
                conn.setRequestMethod("POST");
                conn.setDoOutput(true);
                os = conn.getOutputStream();
                int i = 0;
                while (i < 1 * 1024 * 1024) {
                    os.write("1".getBytes());
                    i++;
                }
                os.flush();
                os.close();
            } catch (IOException e) {
                e.printStackTrace();
            } finally {
                if (null != os) {
                    try {
                        os.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
                if (null != conn) {
                    conn.disconnect();
                }
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void s) {
            //当任务执行完毕之后，需要调用jobFinished来让系统知道这个任务已经结束，
            //系统可以将下一个任务添加到队列中
            //true表示需要重复执行
            jobFinished(jobParameters, true);
            Log.i(TAG, jobParameters.getJobId() + "任务执行完成......");
        }
    }

}
